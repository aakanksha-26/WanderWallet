"""
Database initialization and connection management.
Uses SQLite with WAL mode for concurrency.
Applies schema.sql and seed_data.sql on first run.
"""

import os
import sqlite3
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent
SCHEMA_PATH = BASE_DIR / 'data-model' / 'schema.sql'
SEED_PATH = BASE_DIR / 'data-model' / 'seed' / 'seed_data.sql'
db_url = os.getenv('DATABASE_URL', '').strip()
DB_PATH = Path(db_url) if db_url else (BASE_DIR / 'backend' / 'tripwallet.db')


def get_db():
    """Return a SQLite connection with row_factory and DECIMAL support."""
    conn = sqlite3.connect(
        str(DB_PATH),
        detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """Create tables and seed data if not already present."""
    db_exists = DB_PATH.exists()
    conn = get_db()
    try:
        # Always apply schema (CREATE IF NOT EXISTS)
        with open(SCHEMA_PATH, 'r') as f:
            conn.executescript(f.read())

        # Seed only on first run
        if not db_exists:
            print("📦 Seeding database...")
            with open(SEED_PATH, 'r') as f:
                conn.executescript(f.read())
            print("✅ Database seeded successfully.")
        
        conn.commit()
        print(f"✅ Database ready at {DB_PATH}")
    except Exception as e:
        print(f"❌ Database init error: {e}")
        raise
    finally:
        conn.close()


def query_db(query, args=(), one=False):
    """Execute a SELECT query and return results."""
    conn = get_db()
    try:
        cur = conn.execute(query, args)
        rv = cur.fetchall()
        return (rv[0] if rv else None) if one else rv
    finally:
        conn.close()


def mutate_db(query, args=()):
    """Execute an INSERT/UPDATE/DELETE and return lastrowid."""
    conn = get_db()
    try:
        cur = conn.execute(query, args)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def executemany_db(query, args_list):
    """Execute a query for multiple rows."""
    conn = get_db()
    try:
        conn.executemany(query, args_list)
        conn.commit()
    finally:
        conn.close()


def row_to_dict(row):
    """Convert sqlite3.Row to plain dict."""
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows):
    """Convert list of sqlite3.Row to list of dicts."""
    return [dict(r) for r in rows]
