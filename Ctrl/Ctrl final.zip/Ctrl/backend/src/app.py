"""
WanderWallet — Backend API Server
Flask REST API with SQLite database, decimal math, and AI services.
"""

import os
import sys
from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add src to path
sys.path.insert(0, os.path.dirname(__file__))

from db.database import init_db
from routes.trips import trips_bp
from routes.expenses import expenses_bp
from routes.budgets import budgets_bp
from routes.fx import fx_bp
from routes.ai_routes import ai_bp
from routes.receipts import receipts_bp
from routes.settlement import settlement_bp
from routes.dashboard import dashboard_bp
from routes.itineraries import itineraries_bp
from routes.hotels import hotels_bp
from routes.transit import transit_bp


def create_app():
    app = Flask(__name__)
    app.config['JSON_SORT_KEYS'] = False

    # CORS — allow frontend dev server
    CORS(app, origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5500",
        "null",  # file:// protocol for demo
    ], supports_credentials=True)

    # Register blueprints
    app.register_blueprint(trips_bp,      url_prefix='/api/trips')
    app.register_blueprint(expenses_bp,   url_prefix='/api/expenses')
    app.register_blueprint(budgets_bp,    url_prefix='/api/budgets')
    app.register_blueprint(fx_bp,         url_prefix='/api/fx')
    app.register_blueprint(ai_bp,         url_prefix='/api/ai')
    app.register_blueprint(receipts_bp,   url_prefix='/api/receipts')
    app.register_blueprint(settlement_bp, url_prefix='/api/settlement')
    app.register_blueprint(dashboard_bp,  url_prefix='/api/dashboard')
    app.register_blueprint(itineraries_bp, url_prefix='/api/itineraries')
    app.register_blueprint(hotels_bp,     url_prefix='/api/hotels')
    app.register_blueprint(transit_bp,    url_prefix='/api/transit')

    # Health check
    @app.route('/api/health')
    def health():
        return {'status': 'ok', 'service': 'WanderWallet Backend', 'version': '1.0.0'}

    # Initialize database
    with app.app_context():
        init_db()

    return app


if __name__ == '__main__':
    app = create_app()
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_ENV', 'development') == 'development'
    print(f"🚀 WanderWallet Backend running on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=debug)
