"""
AI Routes — OCR, NL Parser, Spend Forecasting, CFO Chat
"""

import re
import base64
import io
from datetime import datetime, timezone, date
from decimal import Decimal, ROUND_HALF_UP
from flask import Blueprint, request, jsonify
from db.database import query_db, rows_to_list, row_to_dict, mutate_db
import uuid

ai_bp = Blueprint('ai', __name__)
MONEY_DP = Decimal('0.01')

# ═══════════════════════════════════════════════════════════════════
#  AI Feature 1: Receipt OCR
# ═══════════════════════════════════════════════════════════════════

CATEGORY_KEYWORDS = {
    'food':          ['restaurant', 'cafe', 'food', 'dinner', 'lunch', 'breakfast', 'coffee',
                      'pizza', 'burger', 'biryani', 'hotel dining', 'bar', 'pub', 'grill', 'bakery'],
    'transport':     ['taxi', 'uber', 'ola', 'cab', 'fuel', 'petrol', 'bus', 'train',
                      'flight', 'airline', 'metro', 'auto', 'rickshaw', 'parking'],
    'accommodation': ['hotel', 'resort', 'hostel', 'airbnb', 'inn', 'lodge', 'guesthouse', 'room'],
    'activities':    ['diving', 'tour', 'ticket', 'entry', 'museum', 'spa', 'adventure',
                      'trekking', 'safari', 'show', 'concert', 'yoga'],
    'shopping':      ['shop', 'mall', 'market', 'store', 'boutique', 'duty free', 'souvenir'],
    'health':        ['pharmacy', 'medical', 'clinic', 'hospital', 'medicine', 'doctor'],
}

CURRENCY_PATTERNS = {
    'INR': [r'₹\s*[\d,]+', r'INR\s*[\d,]+', r'Rs\.?\s*[\d,]+'],
    'USD': [r'\$\s*[\d,]+', r'USD\s*[\d,]+'],
    'EUR': [r'€\s*[\d,]+', r'EUR\s*[\d,]+'],
    'GBP': [r'£\s*[\d,]+', r'GBP\s*[\d,]+'],
    'THB': [r'฿\s*[\d,]+', r'THB\s*[\d,]+'],
}


def _extract_from_text(text: str) -> dict:
    """Extract expense fields from OCR text using pattern matching."""
    text_lower = text.lower()
    result = {'merchant': None, 'amount': None, 'currency': 'INR', 'date': None, 'category': 'misc'}

    # Extract merchant (first non-empty line, typically)
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    if lines:
        result['merchant'] = lines[0][:60]

    # Extract amount — look for total/amount patterns
    amount_patterns = [
        r'(?:total|amount|grand total|net amount|payable|bill amount)[:\s]*[₹$€£฿]?\s*([\d,]+\.?\d*)',
        r'[₹$€£฿]\s*([\d,]+\.?\d*)',
        r'([\d,]+\.\d{2})\s*(?:INR|USD|EUR|GBP)',
    ]
    for pattern in amount_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            amt_str = match.group(1).replace(',', '')
            try:
                result['amount'] = float(amt_str)
                break
            except ValueError:
                pass

    # Extract currency
    for cur, patterns in CURRENCY_PATTERNS.items():
        for p in patterns:
            if re.search(p, text, re.IGNORECASE):
                result['currency'] = cur
                break

    # Extract date
    date_patterns = [
        r'(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
        r'(\d{4}-\d{2}-\d{2})',
        r'(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{4})',
    ]
    for pattern in date_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            result['date'] = match.group(1)
            break
    if not result['date']:
        result['date'] = str(date.today())

    # Extract category
    best_cat = 'misc'
    best_count = 0
    for cat, keywords in CATEGORY_KEYWORDS.items():
        count = sum(1 for kw in keywords if kw in text_lower)
        if count > best_count:
            best_count = count
            best_cat = cat
    result['category'] = best_cat

    # Confidence score
    confidence = min(100.0, 20.0 +
                     (30.0 if result['amount'] else 0) +
                     (20.0 if result['merchant'] else 0) +
                     (15.0 if result['date'] != str(date.today()) else 0) +
                     (15.0 if best_count > 0 else 0))
    result['confidence'] = round(confidence, 1)

    return result


@ai_bp.route('/ocr', methods=['POST'])
def ocr_receipt():
    """
    Process a receipt image (base64 or uploaded file).
    Uses Tesseract if available, falls back to pattern demo extraction.
    """
    data = request.get_json(force=True)
    trip_id = data.get('trip_id')
    image_b64 = data.get('image_base64', '')
    raw_text_override = data.get('raw_text', '')  # For demo/testing

    if not trip_id:
        return jsonify({'error': 'trip_id required'}), 400

    ocr_text = raw_text_override
    used_tesseract = False

    if not ocr_text and image_b64:
        try:
            # pyrefly: ignore [missing-import]
            import pytesseract
            from PIL import Image
            img_data = base64.b64decode(image_b64.split(',')[-1])
            img = Image.open(io.BytesIO(img_data))
            ocr_text = pytesseract.image_to_string(img)
            used_tesseract = True
        except Exception as e:
            # Tesseract not installed — use demo text
            ocr_text = (
                "GRANDE RESTAURANT GOA\n"
                "Table: 5 | Date: 03/10/2026\n"
                "Prawn Masala        $30.00\n"
                "Fish Curry          $15.00\n"
                "Drinks              $10.00\n"
                "Total:              $55.00 USD\n"
                "Thank you for dining with us!"
            )

    if not ocr_text:
        # Demo mode with sample receipt
        ocr_text = (
            "GRANDE RESTAURANT GOA\n"
            "Date: 03/10/2026\n"
            "Seafood Dinner      $55.00\n"
            "Total: $55.00 USD"
        )

    extracted = _extract_from_text(ocr_text)

    # Save receipt record
    rcp_id = f"rcp_{uuid.uuid4().hex[:12]}"
    now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3] + 'Z'

    mutate_db(
        """INSERT INTO receipts (rcp_id, rcp_trip_id, rcp_image_data, rcp_ocr_raw_text,
           rcp_ocr_merchant, rcp_ocr_amount, rcp_ocr_currency, rcp_ocr_date,
           rcp_ocr_category, rcp_ocr_confidence, rcp_ocr_processed_at, status,
           created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,'processed',?,?)""",
        (rcp_id, trip_id, image_b64[:500] if image_b64 else None, ocr_text,
         extracted['merchant'], extracted['amount'], extracted['currency'],
         extracted['date'], extracted['category'], extracted['confidence'], now, now, now)
    )

    return jsonify({
        'receipt_id': rcp_id,
        'ocr_text': ocr_text,
        'extracted': extracted,
        'used_tesseract': used_tesseract,
        'pre_filled': {
            'title': extracted['merchant'] or 'Receipt Expense',
            'amount': extracted['amount'],
            'currency': extracted['currency'],
            'category': extracted['category'],
            'date': extracted['date'],
            'entered_via': 'ocr',
        }
    })


# ═══════════════════════════════════════════════════════════════════
#  AI Feature 2: Natural Language Expense Parser
# ═══════════════════════════════════════════════════════════════════

NL_AMOUNT_PATTERN = re.compile(
    r'(?:₹|rs\.?|inr|usd|\$|eur|€|gbp|£|thb|฿)?\s*'
    r'([\d,]+(?:\.\d+)?)\s*'
    r'(?:₹|rs\.?|inr|usd|\$|eur|€|gbp|£|thb|฿)?',
    re.IGNORECASE
)
NL_CURRENCY_MAP = {
    '₹': 'INR', 'rs': 'INR', 'inr': 'INR',
    '$': 'USD', 'usd': 'USD',
    '€': 'EUR', 'eur': 'EUR',
    '£': 'GBP', 'gbp': 'GBP',
    '฿': 'THB', 'thb': 'THB',
}
NL_CATEGORY_KEYWORDS = {
    'food':          ['dinner', 'lunch', 'breakfast', 'food', 'ate', 'meal', 'cafe', 'restaurant',
                      'coffee', 'drink', 'pizza', 'biryani', 'snack'],
    'transport':     ['cab', 'taxi', 'uber', 'ola', 'bus', 'train', 'flight', 'auto', 'rickshaw',
                      'fuel', 'petrol', 'travel', 'transport', 'ride'],
    'accommodation': ['hotel', 'resort', 'stay', 'room', 'hostel', 'airbnb', 'checkin', 'checkout'],
    'activities':    ['diving', 'tour', 'trek', 'hike', 'museum', 'beach', 'adventure', 'activity',
                      'show', 'ticket', 'spa', 'yoga'],
    'shopping':      ['bought', 'purchase', 'shopping', 'market', 'souvenir', 'clothes', 'bag'],
    'health':        ['medicine', 'pharmacy', 'medical', 'doctor', 'hospital'],
    'misc':          ['misc', 'other', 'miscellaneous'],
}


def _parse_nl_input(text: str, trip_id: str) -> dict:
    text_lower = text.lower()

    # Extract amount + currency
    amount = None
    currency = 'INR'
    
    # Find currency symbol first
    for sym, cur in sorted(NL_CURRENCY_MAP.items(), key=lambda x: -len(x[0])):
        if sym in text_lower:
            currency = cur
            break

    # Extract number
    matches = NL_AMOUNT_PATTERN.findall(text)
    for m in matches:
        try:
            amount = float(m.replace(',', ''))
            if amount > 0:
                break
        except ValueError:
            pass

    # Extract category
    category = 'misc'
    best_count = 0
    for cat, keywords in NL_CATEGORY_KEYWORDS.items():
        count = sum(1 for kw in keywords if kw in text_lower)
        if count > best_count:
            best_count = count
            category = cat

    # Extract title — remove amount patterns, currency symbols, split words
    title = text
    for sym in ['₹', '$', '€', '£', '฿']:
        title = title.replace(sym, '')
    title = re.sub(r'\b\d[\d,.]*\b', '', title)
    stop_words = ['split', 'between', 'with', 'and', 'add', 'paid', 'for',
                  'inr', 'usd', 'eur', 'gbp', 'thb', 'rs', 'rupees']
    title_words = [w for w in title.split() if w.lower() not in stop_words]
    title = ' '.join(title_words).strip().title() or 'Expense'

    # Extract member names for split
    split_members_raw = []
    split_match = re.search(
        r'split\s+(?:between\s+|with\s+)?([\w\s,&and]+?)(?:\s+equally|\s+equal|$)',
        text, re.IGNORECASE
    )
    if split_match:
        raw = split_match.group(1)
        names = re.split(r'[,&]|\band\b', raw, flags=re.IGNORECASE)
        split_members_raw = [n.strip() for n in names if n.strip()]

    # Resolve names to user IDs
    split_user_ids = []
    if split_members_raw and trip_id:
        all_members = rows_to_list(query_db(
            """SELECT u.usr_id, u.usr_name
               FROM trip_members tm JOIN users u ON u.usr_id = tm.tmb_user_id
               WHERE tm.tmb_trip_id = ? AND tm.status = 'active'""",
            (trip_id,)
        ))
        for raw_name in split_members_raw:
            for member in all_members:
                if raw_name.lower() in member['usr_name'].lower():
                    split_user_ids.append(member['usr_id'])
                    break

    confidence = min(100.0,
                     (40.0 if amount else 0) +
                     (20.0 if best_count > 0 else 10.0) +
                     (20.0 if len(title) > 3 else 5.0) +
                     (20.0 if split_user_ids else 5.0))

    return {
        'amount': amount,
        'currency': currency,
        'category': category,
        'title': title,
        'split_members': split_user_ids,
        'split_members_raw': split_members_raw,
        'split_type': 'equal' if split_user_ids else 'none',
        'date': str(date.today()),
        'entered_via': 'nl_parse',
        'confidence': round(confidence, 1),
    }


@ai_bp.route('/parse-nl', methods=['POST'])
def parse_nl():
    """Parse natural language expense input."""
    data = request.get_json(force=True)
    text = data.get('text', '').strip()
    trip_id = data.get('trip_id', '')

    if not text:
        return jsonify({'error': 'text is required'}), 400

    parsed = _parse_nl_input(text, trip_id)
    return jsonify({
        'input': text,
        'parsed': parsed,
        'pre_filled': {
            'title': parsed['title'],
            'amount': parsed['amount'],
            'currency': parsed['currency'],
            'category': parsed['category'],
            'date': parsed['date'],
            'split_type': parsed['split_type'],
            'split_members': parsed['split_members'],
            'entered_via': 'nl_parse',
            'source_text': text,
        }
    })


# ═══════════════════════════════════════════════════════════════════
#  AI Feature 3: Spend Forecasting
# ═══════════════════════════════════════════════════════════════════

@ai_bp.route('/forecast/<trip_id>', methods=['GET'])
def forecast_spend(trip_id):
    """Recency-weighted burn rate forecasting."""
    trip = row_to_dict(query_db(
        "SELECT * FROM trips WHERE trp_id = ? AND status = 'active'",
        (trip_id,), one=True
    ))
    if not trip:
        return jsonify({'error': 'Trip not found'}), 404

    budget = row_to_dict(query_db(
        "SELECT bud_total_amount FROM budgets WHERE bud_trip_id = ? AND status = 'active'",
        (trip_id,), one=True
    ))
    total_budget = Decimal(str(budget['bud_total_amount'])) if budget else Decimal('0')

    # Daily spend data
    daily = rows_to_list(query_db(
        """SELECT exp_date, SUM(exp_home_amount) as day_total
           FROM expenses WHERE exp_trip_id = ? AND status = 'active'
           GROUP BY exp_date ORDER BY exp_date""",
        (trip_id,)
    ))

    if not daily:
        return jsonify({'projected_total': 0, 'daily_burn_rate': 0, 'risk': 'unknown'})

    # Parse trip dates
    start = date.fromisoformat(trip['trp_start_date'])
    end = date.fromisoformat(trip['trp_end_date'])
    today = date.today()
    trip_days = max(1, (end - start).days + 1)
    elapsed_days = max(1, (min(today, end) - start).days + 1)
    remaining_days = max(0, (end - today).days)

    # Recency-weighted burn rate (recent days weighted more)
    if len(daily) == 1:
        burn_rate = Decimal(str(daily[0]['day_total']))
    else:
        weights_sum = Decimal('0')
        weighted_total = Decimal('0')
        for i, d in enumerate(daily):
            w = Decimal(str(i + 1))  # recency weight
            weighted_total += w * Decimal(str(d['day_total']))
            weights_sum += w
        burn_rate = (weighted_total / weights_sum).quantize(MONEY_DP) if weights_sum else Decimal('0')

    total_spent = sum(Decimal(str(d['day_total'])) for d in daily)
    projected_remaining = burn_rate * Decimal(str(remaining_days))
    projected_total = (total_spent + projected_remaining).quantize(MONEY_DP)
    projected_overshoot = max(Decimal('0'), projected_total - total_budget)

    if total_budget > 0:
        risk_pct = float((projected_total / total_budget) * 100)
        risk = 'critical' if risk_pct > 110 else 'high' if risk_pct > 95 else 'medium' if risk_pct > 80 else 'low'
    else:
        risk = 'unknown'
        risk_pct = 0.0

    return jsonify({
        'trip_id': trip_id,
        'elapsed_days': elapsed_days,
        'remaining_days': remaining_days,
        'trip_total_days': trip_days,
        'total_spent': float(total_spent),
        'daily_burn_rate': float(burn_rate),
        'projected_total': float(projected_total),
        'projected_overshoot': float(projected_overshoot),
        'total_budget': float(total_budget),
        'risk': risk,
        'risk_pct': round(risk_pct, 1),
        'daily_data': daily,
    })


# ═══════════════════════════════════════════════════════════════════
#  AI Feature 4: CFO Chat (Budget-grounded Q&A)
# ═══════════════════════════════════════════════════════════════════

from services.recommendation_service import get_ai_recommendations

@ai_bp.route('/recommendations/<trip_id>', methods=['GET'])
def trip_recommendations(trip_id):
    """Proactive budget recommendations and destination alternatives."""
    data = get_ai_recommendations(trip_id)
    return jsonify(data)


@ai_bp.route('/cfo-chat', methods=['POST'])
def cfo_chat():
    """
    AI Travel CFO: answers questions about trip budget using exact DB data.
    Deterministic rule engine — grounded in actual numbers.
    """
    data = request.get_json(force=True)
    question = data.get('question', '').strip().lower()
    trip_id = data.get('trip_id', '')

    if not question or not trip_id:
        return jsonify({'error': 'question and trip_id are required'}), 400

    # Fetch context
    trip = row_to_dict(query_db("SELECT * FROM trips WHERE trp_id = ?", (trip_id,), one=True))
    budget = row_to_dict(query_db("SELECT * FROM budgets WHERE bud_trip_id = ? AND status='active'", (trip_id,), one=True))

    from services.breach_detector import check_breach
    breach_data = check_breach(trip_id)
    total_spent = Decimal(str(breach_data.get('total_spent', 0)))
    total_budget = Decimal(str(breach_data.get('total_cap', 0)))
    remaining = (total_budget - total_spent).quantize(MONEY_DP)
    home_cur = trip['trp_home_currency'] if trip else 'INR'
    sym = {'INR': '₹', 'USD': '$', 'EUR': '€', 'GBP': '£'}.get(home_cur, home_cur + ' ')

    # Rule-based response engine with recommendations
    response = _cfo_answer(question, remaining, total_spent, total_budget,
                           breach_data, sym, home_cur, budget, trip_id)

    return jsonify({
        'question': data.get('question'),
        'answer': response['answer'],
        'data': {
            'remaining': float(remaining),
            'total_spent': float(total_spent),
            'total_budget': float(total_budget),
            'currency': home_cur,
        },
        'confidence': response['confidence'],
    })


def _cfo_answer(q: str, remaining: Decimal, spent: Decimal, budget: Decimal,
                breach_data: dict, sym: str, currency: str, bud_row: dict | None, trip_id: str | None = None) -> dict:
    q = q.lower()

    # 1. Recommendations & Budget Optimization
    if any(w in q for w in ['recommend', 'suggestion', 'optimize', 'cheaper', 'alternative', 'advice', 'save money', 'cut cost']):
        if trip_id:
            recs_data = get_ai_recommendations(trip_id)
            recs = recs_data.get('recommendations', [])
            if recs:
                top = recs[0]
                secondary = recs[1] if len(recs) > 1 else None
                ans = f"💡 **AI Budget Optimization for {recs_data.get('destination', 'Your Trip')}**:\n\n"
                ans += f"1. **{top['title']}**: {top['description']} ({top['formatted_savings']})\n"
                if secondary:
                    ans += f"\n2. **{secondary['title']}**: {secondary['description']} ({secondary['formatted_savings']})\n"
                ans += f"\n🎯 Total potential savings: **{recs_data.get('formatted_total_savings')}**. {recs_data.get('rebalancing_advice', '')}"
                return {'answer': ans, 'confidence': 0.96}

    # 2. Scuba diving & specific activities affordability
    if 'scuba' in q or 'diving' in q:
        scuba_est = Decimal('4500.00')
        if remaining >= scuba_est:
            return {
                'answer': (f"🤿 **Yes, you can afford scuba diving tomorrow!**\n\n"
                           f"Estimated cost: {sym}{scuba_est:,.2f}.\n"
                           f"Current remaining budget: {sym}{remaining:,.2f}.\n"
                           f"After scuba diving, you'll still have {sym}{remaining - scuba_est:,.2f} safe runway left. "
                           f"Pro-tip: Early morning boats at Grande Island cost ~25% less!"),
                'confidence': 0.95
            }
        else:
            return {
                'answer': (f"⚠️ **Scuba diving is tight.**\n\n"
                           f"A typical session is ~{sym}{scuba_est:,.2f}, but your remaining budget is only {sym}{remaining:,.2f}. "
                           f"You'd overshoot by {sym}{scuba_est - remaining:,.2f}. Consider saving on dinner tonight or booking an afternoon group snorkel!"),
                'confidence': 0.92
            }

    # 3. Who owes me money / group settlement
    if any(w in q for w in ['who owes', 'debt', 'settle', 'owe me', 'split balance', 'pay me']):
        if trip_id:
            from services.settlement_service import compute_settlement
            try:
                settlement = compute_settlement(trip_id)
                txs = settlement.get('transactions', [])
                bals = settlement.get('balances', [])
                if not txs:
                    return {'answer': "🎉 **All group balances are settled!** Nobody owes anyone any money right now.", 'confidence': 0.98}
                
                msg = "🤝 **Current Group Settlement Status**:\n\n"
                for tx in txs:
                    msg += f"• **{tx['from_user_name']}** pays **{tx['to_user_name']}**: {sym}{tx['amount']:,.2f}\n"
                return {'answer': msg, 'confidence': 0.96}
            except Exception:
                pass

    # 4. Will we exceed our budget / overspending prediction
    if any(w in q for w in ['exceed', 'over budget', 'will we run out', 'overshoot', 'forecast']):
        from routes.ai_routes import forecast_spend
        pct_used = breach_data.get('total_pct', 0)
        breaches = breach_data.get('breaches', [])
        if breaches:
            b = breaches[0]
            return {
                'answer': (f"🚨 **High Alert: You are on track to exceed budget.**\n\n"
                           f"{b['message']}.\n"
                           f"Current spend is at {pct_used:.1f}% of total cap. "
                           f"We recommend capping dining at {sym}800/day for the rest of the trip to re-stabilize."),
                'confidence': 0.95
            }
        else:
            return {
                'answer': (f"✅ **You are on track!**\n\n"
                           f"You've spent {sym}{spent:,.2f} of {sym}{budget:,.2f} ({pct_used:.1f}% used). "
                           f"With {sym}{remaining:,.2f} remaining, steady daily spend will keep you well within limits."),
                'confidence': 0.94
            }

    # 5. Can I afford X
    if any(w in q for w in ['afford', 'can i', 'have enough', 'budget for']):
        amt_match = re.search(r'[\d,]+(?:\.\d+)?', q)
        if amt_match:
            try:
                ask_amount = Decimal(amt_match.group().replace(',', ''))
                if remaining >= ask_amount:
                    ans = (f"✅ **Yes! You can comfortably afford that.**\n\n"
                           f"You have {sym}{remaining:,.2f} remaining in your budget. "
                           f"Cost: {sym}{ask_amount:,.2f} → Remaining after: {sym}{remaining - ask_amount:,.2f}.")
                else:
                    ans = (f"⚠️ **Caution: Budget Stretch.**\n\n"
                           f"You have {sym}{remaining:,.2f} left, but {sym}{ask_amount:,.2f} will exceed your budget by {sym}{ask_amount - remaining:,.2f}. "
                           f"Consider reallocating from miscellaneous funds or finding an off-peak rate.")
                return {'answer': ans, 'confidence': 0.92}
            except Exception:
                pass
        return {
            'answer': f"You have {sym}{remaining:,.2f} left in your trip budget. What specific activity or item are you planning?",
            'confidence': 0.85
        }

    # 6. Food expenses
    if any(w in q for w in ['food', 'dining', 'restaurant', 'eat', 'dinner', 'lunch']):
        cat = breach_data.get('category_summary', {}).get('food', {})
        if cat and cat.get('cap'):
            status_emoji = '🚨' if cat.get('status') == 'breached' else '🍽️'
            return {
                'answer': (f"{status_emoji} **Food Spending Breakdown**:\n\n"
                           f"• Total Spent: {sym}{cat['spent']:,.2f}\n"
                           f"• Allocated Cap: {sym}{cat['cap']:,.2f}\n"
                           f"• Used: {cat.get('pct_used', 0):.1f}%\n"
                           f"• Status: **{cat.get('status', 'ok').upper()}**"
                           + (f" (Overshoot: {sym}{cat.get('overshoot', 0):,.2f})" if cat.get('overshoot', 0) > 0 else "")),
                'confidence': 0.95
            }

    # 7. Remaining balance
    if any(w in q for w in ['remaining', 'left', 'balance', 'how much']):
        pct_used = breach_data.get('total_pct', 0)
        return {
            'answer': (f"💰 **Live Financial Position**:\n\n"
                       f"• Total Budget: {sym}{budget:,.2f}\n"
                       f"• Total Spent: {sym}{spent:,.2f} ({pct_used:.1f}%)\n"
                       f"• Remaining Runway: **{sym}{remaining:,.2f}**"),
            'confidence': 0.98
        }

    # 8. Breaches & Alerts
    if any(w in q for w in ['breach', 'alert', 'warning']):
        breaches = breach_data.get('breaches', [])
        if breaches:
            b = breaches[0]
            return {
                'answer': (f"🚨 **Active Cap Alerts ({len(breaches)})**:\n\n"
                           f"• **{b['category'].upper()}**: {b['message']}"),
                'confidence': 0.97
            }
        return {'answer': "✅ All categories are operating strictly within their allocated caps.", 'confidence': 0.97}

    # Default helpful response
    return {
        'answer': (f"📊 **Trip Financial Summary**:\n\n"
                   f"Spent {sym}{spent:,.2f} of {sym}{budget:,.2f} ({breach_data.get('total_pct', 0):.1f}%). "
                   f"Safe remaining balance: **{sym}{remaining:,.2f}**.\n\n"
                   f"Try asking:\n"
                   f"• *'Can I afford scuba diving tomorrow?'*\n"
                   f"• *'How much did we spend on food?'*\n"
                   f"• *'Who owes me money?'*\n"
                   f"• *'Give me suggestions to optimize our budget'*"),
        'confidence': 0.85
    }
